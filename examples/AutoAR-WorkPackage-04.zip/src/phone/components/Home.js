// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

console.log($scope.app);

$scope.setVin = function (vin) {
  
  $scope.app.params.vin = vin;
  
  
  var parameters = {'vin': vin};
  
  twx.app.fn.triggerDataService('AutoARServiceHelper', 'GetHeroData', parameters);
  
  
  
}


// *********************************************************
// For example do something after 1750 milliseconds a service finishes  
// *********************************************************
$scope.$on("GetHeroData.serviceInvokeComplete", function(evt, arg){
       
  		$scope.navigate('VIN_OCTO');
  
	}

);


 